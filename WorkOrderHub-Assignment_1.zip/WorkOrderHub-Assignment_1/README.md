# WorkOrderHub (Enhanced Starter)

Group Members:
- Dhiraj
- Komal
- Maaz

This package is a runnable, student-level implementation of the core system.
It includes backend + frontend + CSV bulk upload (partial acceptance).

## Run Backend
```bash
cd backend
npm install
npm run dev
```
- Health: GET http://localhost:3001/health
- API key header for /api/**: x-api-key: WORKORDER123

## Run Frontend
```bash
cd frontend
npm install
npm run dev
```
Open: http://localhost:3000

## CSV Upload
Use page: /bulk-upload
Or POST:
- /api/workorders/bulk-upload (field name: file)
- /api/workorders/data-transfer (alias)
Sample CSV: sample/workorders-sample.csv
