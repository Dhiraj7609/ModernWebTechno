export default function ErrorBanner({ result }: { result: any }) {
  return (
    <div style={{ padding: 12, background: "#ffecec", border: "1px solid #f5b5b5", marginBottom: 12 }}>
      <strong>Error</strong>
      <div>requestId: {result?.requestId || "unknown"}</div>
      <div>code: {result?.error?.code || "UNKNOWN"}</div>
      <div>message: {result?.error?.message || "Something went wrong"}</div>
      {result?.error?.details ? <pre style={{ whiteSpace: "pre-wrap" }}>{JSON.stringify(result.error.details, null, 2)}</pre> : null}
    </div>
  );
}
