import Link from "next/link";

export default function Sidebar() {
  return (
    <aside style={{ width: 220, borderRight: "1px solid #ddd", padding: 12 }}>
      <h3>WorkOrderHub</h3>
      <nav style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        <Link href="/">Home</Link>
        <Link href="/dashboard">Dashboard</Link>
        <Link href="/workorders">Work Orders</Link>
        <Link href="/workorders/create">Create</Link>
        <Link href="/bulk-upload">Bulk Upload</Link>
        <Link href="/help">Help</Link>
      </nav>
    </aside>
  );
}
