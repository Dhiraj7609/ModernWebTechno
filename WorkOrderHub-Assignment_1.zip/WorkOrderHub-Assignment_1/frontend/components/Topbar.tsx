export default function Topbar(){return <div style={{borderBottom:'1px solid #ddd',padding:12}}>TPS-aligned WorkOrderHub (student-level)</div>;}
