type ApiOk<T> = { ok: true; requestId: string; data: T };
type ApiErr = { ok: false; requestId: string; error: { code: string; message: string; details?: any[] } };
export type ApiResult<T> = ApiOk<T> | ApiErr;

const BASE = process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:3001";
const KEY = process.env.NEXT_PUBLIC_API_KEY || "";

async function request<T>(path: string, init?: RequestInit): Promise<ApiResult<T>> {
  try {
    const res = await fetch(`${BASE}${path}`, {
      ...init,
      headers: {
        "x-api-key": KEY,
        ...(init?.headers || {})
      }
    });

    if (res.status === 204) {
      return { ok: true, requestId: res.headers.get("x-request-id") || "unknown", data: null as any };
    }

    const json = await res.json();

    if (json?.success) {
      return { ok: true, requestId: json.requestId, data: json.data };
    }
    return { ok: false, requestId: json.requestId || "unknown", error: json.error || { code: "UNKNOWN", message: "Unknown error" } };
  } catch (e: any) {
    return { ok: false, requestId: "client", error: { code: "CLIENT_ERROR", message: e?.message || "Network error" } };
  }
}

export function listWorkOrders(params: any) {
  const usp = new URLSearchParams();
  Object.entries(params || {}).forEach(([k, v]) => { if (v !== undefined && v !== null && v !== "") usp.set(k, String(v)); });
  const q = usp.toString();
  return request<any>(`/api/workorders${q ? `?${q}` : ""}`, { method: "GET" });
}

export function getWorkOrder(id: string) {
  return request<any>(`/api/workorders/${id}`, { method: "GET" });
}

export function createWorkOrder(payload: any) {
  return request<any>(`/api/workorders`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });
}

export function updateWorkOrder(id: string, payload: any) {
  return request<any>(`/api/workorders/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });
}

export function changeStatus(id: string, status: string) {
  return request<any>(`/api/workorders/${id}/status`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ status })
  });
}

export function deleteWorkOrder(id: string) {
  return request<any>(`/api/workorders/${id}`, { method: "DELETE" });
}

export async function bulkUploadCsv(file: File) {
  const form = new FormData();
  form.append("file", file);
  return request<any>(`/api/workorders/bulk-upload`, { method: "POST", body: form });
}
