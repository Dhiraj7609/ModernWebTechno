import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { listWorkOrders } from "../services/api";
import ErrorBanner from "../components/ErrorBanner";

const STATUSES = ["NEW", "IN_PROGRESS", "BLOCKED", "DONE"];

export default function Dashboard() {
  const [data, setData] = useState<any>(null);
  const [err, setErr] = useState<any>(null);

  useEffect(() => {
    (async () => {
      const res = await listWorkOrders({ page: 1, limit: 100 });
      if (!res.ok) return setErr(res);
      setData(res.data);
    })();
  }, []);

  const byStatus = useMemo(() => {
    const map: any = { NEW: [], IN_PROGRESS: [], BLOCKED: [], DONE: [] };
    const items = data?.items || [];
    items.forEach((w: any) => map[w.status]?.push(w));
    return map;
  }, [data]);

  if (err) return <ErrorBanner result={err} />;
  if (!data) return <div style={{ padding: 16 }}>Loading…</div>;

  return (
    <div style={{ padding: 16 }}>
      <h2>Dashboard Board</h2>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12 }}>
        {STATUSES.map((s) => (
          <div key={s} style={{ border: "1px solid #ddd", borderRadius: 6, padding: 10 }}>
            <h3 style={{ marginTop: 0 }}>{s}</h3>
            {(byStatus[s] || []).map((w: any) => (
              <div key={w.id} style={{ padding: 8, border: "1px solid #eee", borderRadius: 6, marginBottom: 8 }}>
                <div style={{ fontWeight: 600 }}>{w.title}</div>
                <div style={{ fontSize: 12 }}>{w.department} • {w.priority}</div>
                <Link href={`/workorders/${w.id}`} style={{ fontSize: 12 }}>Open</Link>
              </div>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}
