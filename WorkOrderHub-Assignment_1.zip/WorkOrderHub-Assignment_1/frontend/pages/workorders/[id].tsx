import { useRouter } from "next/router";
import { useEffect, useMemo, useState } from "react";
import ErrorBanner from "../../components/ErrorBanner";
import { getWorkOrder, changeStatus, updateWorkOrder, deleteWorkOrder } from "../../services/api";

const NEXT_BY_STATUS: any = {
  NEW: ["IN_PROGRESS"],
  IN_PROGRESS: ["BLOCKED", "DONE"],
  BLOCKED: ["IN_PROGRESS"],
  DONE: []
};

export default function WorkOrderDetails() {
  const router = useRouter();
  const { id } = router.query;
  const [data, setData] = useState<any>(null);
  const [err, setErr] = useState<any>(null);

  async function load() {
    if (!id || typeof id !== "string") return;
    const res = await getWorkOrder(id);
    if (!res.ok) return setErr(res);
    setData(res.data);
  }

  useEffect(() => { load(); }, [id]);

  const allowedNext = useMemo(() => NEXT_BY_STATUS[data?.status] || [], [data?.status]);

  async function doStatus(status: string) {
    if (!id || typeof id !== "string") return;
    const res = await changeStatus(id, status);
    if (!res.ok) return setErr(res);
    setData(res.data);
  }

  async function doUpdate() {
    if (!id || typeof id !== "string") return;
    const res = await updateWorkOrder(id, { priority: data.priority, assignee: data.assignee });
    if (!res.ok) return setErr(res);
    setData(res.data);
  }

  async function doDelete() {
    if (!id || typeof id !== "string") return;
    const ok = confirm("Delete this work order?");
    if (!ok) return;
    const res = await deleteWorkOrder(id);
    if (!res.ok) return setErr(res);
    router.push("/workorders");
  }

  if (err) return <ErrorBanner result={err} />;
  if (!data) return <div style={{ padding: 16 }}>Loading…</div>;

  return (
    <div style={{ padding: 16, maxWidth: 900 }}>
      <h2>Work Order Details</h2>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
        <div style={{ border: "1px solid #ddd", borderRadius: 6, padding: 12 }}>
          <h3 style={{ marginTop: 0 }}>Info</h3>
          <div><b>Title:</b> {data.title}</div>
          <div><b>Description:</b> {data.description}</div>
          <div><b>Department:</b> {data.department}</div>
          <div><b>Status:</b> {data.status}</div>
          <div><b>Requester:</b> {data.requesterName}</div>
        </div>

        <div style={{ border: "1px solid #ddd", borderRadius: 6, padding: 12 }}>
          <h3 style={{ marginTop: 0 }}>Edit (Allowed fields)</h3>
          <label>Priority:
            <select value={data.priority} onChange={(e)=>setData({...data, priority: e.target.value})}>
              <option>LOW</option><option>MEDIUM</option><option>HIGH</option>
            </select>
          </label><br/><br/>
          <label>Assignee:
            <input value={data.assignee || ""} onChange={(e)=>setData({...data, assignee: e.target.value})}/>
          </label><br/><br/>
          <button onClick={doUpdate}>Save</button>
        </div>
      </div>

      <div style={{ marginTop: 12, border: "1px solid #ddd", borderRadius: 6, padding: 12 }}>
        <h3 style={{ marginTop: 0 }}>Status Transition</h3>
        {allowedNext.length === 0 ? <div>No transitions allowed.</div> : null}
        {allowedNext.map((s: string) => (
          <button key={s} onClick={()=>doStatus(s)} style={{ marginRight: 8 }}>
            → {s}
          </button>
        ))}
      </div>

      <div style={{ marginTop: 12, border: "1px solid #f3c1c1", borderRadius: 6, padding: 12 }}>
        <h3 style={{ marginTop: 0 }}>Danger Zone</h3>
        <button onClick={doDelete}>Delete</button>
      </div>
    </div>
  );
}
