import { useState } from "react";
import { createWorkOrder } from "../../services/api";
import ErrorBanner from "../../components/ErrorBanner";

export default function CreateWorkOrderPage() {
  const [form, setForm] = useState({
    title: "",
    description: "",
    department: "IT",
    priority: "LOW",
    requesterName: "",
    assignee: ""
  });
  const [err, setErr] = useState<any>(null);
  const [ok, setOk] = useState<any>(null);

  async function onSubmit(e: any) {
    e.preventDefault();
    setErr(null); setOk(null);
    const payload: any = { ...form };
    if (!payload.assignee) delete payload.assignee;

    const res = await createWorkOrder(payload);
    if (!res.ok) return setErr(res);
    setOk(res.data);
  }

  return (
    <div style={{ padding: 16, maxWidth: 720 }}>
      <h2>Create Work Order</h2>
      {err && <ErrorBanner result={err} />}
      {ok && <pre>Created:\n{JSON.stringify(ok, null, 2)}</pre>}

      <form onSubmit={onSubmit}>
        <label>Title<br/>
          <input value={form.title} onChange={(e)=>setForm({...form,title:e.target.value})} style={{width:"100%"}} />
        </label><br/><br/>
        <label>Description<br/>
          <textarea value={form.description} onChange={(e)=>setForm({...form,description:e.target.value})} style={{width:"100%"}} rows={4} />
        </label><br/><br/>
        <label>Department<br/>
          <select value={form.department} onChange={(e)=>setForm({...form,department:e.target.value})}>
            <option>FACILITIES</option><option>IT</option><option>SECURITY</option><option>HR</option>
          </select>
        </label><br/><br/>
        <label>Priority<br/>
          <select value={form.priority} onChange={(e)=>setForm({...form,priority:e.target.value})}>
            <option>LOW</option><option>MEDIUM</option><option>HIGH</option>
          </select>
        </label><br/><br/>
        <label>Requester Name<br/>
          <input value={form.requesterName} onChange={(e)=>setForm({...form,requesterName:e.target.value})} />
        </label><br/><br/>
        <label>Assignee (optional)<br/>
          <input value={form.assignee} onChange={(e)=>setForm({...form,assignee:e.target.value})} />
        </label><br/><br/>
        <button type="submit">Create</button>
      </form>
    </div>
  );
}
