import { useEffect, useState } from "react";
import Link from "next/link";
import ErrorBanner from "../../components/ErrorBanner";
import { listWorkOrders } from "../../services/api";

export default function WorkOrdersList() {
  const [data, setData] = useState<any>(null);
  const [err, setErr] = useState<any>(null);
  const [filters, setFilters] = useState({ status: "", department: "", priority: "", q: "" });

  async function load() {
    const res = await listWorkOrders({ ...filters, page: 1, limit: 10 });
    if (!res.ok) return setErr(res);
    setData(res.data);
  }

  useEffect(() => { load(); }, []);

  if (err) return <ErrorBanner result={err} />;
  if (!data) return <div style={{ padding: 16 }}>Loading…</div>;

  return (
    <div style={{ padding: 16 }}>
      <h2>Work Orders</h2>

      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 12 }}>
        <select value={filters.status} onChange={(e)=>setFilters({...filters,status:e.target.value})}>
          <option value="">Status (all)</option>
          <option>NEW</option><option>IN_PROGRESS</option><option>BLOCKED</option><option>DONE</option>
        </select>
        <select value={filters.department} onChange={(e)=>setFilters({...filters,department:e.target.value})}>
          <option value="">Department (all)</option>
          <option>FACILITIES</option><option>IT</option><option>SECURITY</option><option>HR</option>
        </select>
        <select value={filters.priority} onChange={(e)=>setFilters({...filters,priority:e.target.value})}>
          <option value="">Priority (all)</option>
          <option>LOW</option><option>MEDIUM</option><option>HIGH</option>
        </select>
        <input placeholder="Search title…" value={filters.q} onChange={(e)=>setFilters({...filters,q:e.target.value})}/>
        <button onClick={load}>Apply</button>
        <Link href="/workorders/create" style={{ marginLeft: "auto" }}>+ Create</Link>
      </div>

      <table border={1} cellPadding={8} style={{ borderCollapse: "collapse", width: "100%" }}>
        <thead>
          <tr>
            <th>Title</th><th>Dept</th><th>Priority</th><th>Status</th><th>Open</th>
          </tr>
        </thead>
        <tbody>
          {(data.items || []).map((w: any) => (
            <tr key={w.id}>
              <td>{w.title}</td>
              <td>{w.department}</td>
              <td>{w.priority}</td>
              <td>{w.status}</td>
              <td><Link href={`/workorders/${w.id}`}>View</Link></td>
            </tr>
          ))}
        </tbody>
      </table>

      <div style={{ marginTop: 10, fontSize: 12 }}>
        Showing {data.items?.length || 0} of {data.total}
      </div>
    </div>
  );
}
