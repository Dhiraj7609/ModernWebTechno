export default function Help() {
  return (
    <div style={{ padding: 16 }}>
      <h2>Help</h2>
      <h3>CSV Template</h3>
      <pre>title,description,department,priority,requesterName,assignee</pre>
      <pre>Fix laptop,User cannot login,IT,HIGH,Dhiraj,Maaz</pre>

      <h3>Status Lifecycle</h3>
      <ul>
        <li>NEW → IN_PROGRESS</li>
        <li>IN_PROGRESS → BLOCKED or DONE</li>
        <li>BLOCKED → IN_PROGRESS</li>
        <li>DONE → (no transitions)</li>
      </ul>
    </div>
  );
}
