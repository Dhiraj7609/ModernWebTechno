import { useState } from "react";
import ErrorBanner from "../components/ErrorBanner";
import { bulkUploadCsv } from "../services/api";

export default function BulkUploadPage() {
  const [file, setFile] = useState<File | null>(null);
  const [result, setResult] = useState<any>(null);
  const [err, setErr] = useState<any>(null);

  async function onUpload() {
    setErr(null); setResult(null);
    if (!file) return alert("Choose a CSV first");
    const res = await bulkUploadCsv(file);
    if (!res.ok) return setErr(res);
    setResult(res.data);
  }

  return (
    <div style={{ padding: 16 }}>
      <h2>Bulk Upload CSV</h2>
      <p>Required headers: title, description, department, priority, requesterName (assignee optional)</p>

      {err && <ErrorBanner result={err} />}

      <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
        <input type="file" accept=".csv" onChange={(e)=>setFile(e.target.files?.[0] || null)} />
        <button onClick={onUpload}>Upload</button>
      </div>

      {result && (
        <div style={{ marginTop: 16 }}>
          <h3>Upload Result</h3>
          <div><b>Strategy:</b> {result.strategy}</div>
          <div><b>Total Rows:</b> {result.totalRows}</div>
          <div><b>Accepted:</b> {result.accepted}</div>
          <div><b>Rejected:</b> {result.rejected}</div>

          {result.errors && result.errors.length > 0 ? (
            <>
              <h4>Row Errors</h4>
              <table border={1} cellPadding={8} style={{ borderCollapse: "collapse" }}>
                <thead>
                  <tr><th>Row</th><th>Field</th><th>Reason</th></tr>
                </thead>
                <tbody>
                  {result.errors.map((e: any, i: number) => (
                    <tr key={i}>
                      <td>{e.row}</td>
                      <td>{e.field}</td>
                      <td>{e.reason}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </>
          ) : <div style={{ marginTop: 8 }}>No row errors.</div>}
        </div>
      )}
    </div>
  );
}
