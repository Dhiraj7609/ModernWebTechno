import Link from "next/link";

export default function Home() {
  return (
    <div style={{ padding: 16 }}>
      <h1>WorkOrderHub</h1>
      <p>Enhanced runnable starter (student-level).</p>
      <ul>
        <li><Link href="/dashboard">Dashboard</Link></li>
        <li><Link href="/workorders">Work Orders</Link></li>
        <li><Link href="/workorders/create">Create Work Order</Link></li>
        <li><Link href="/bulk-upload">Bulk Upload</Link></li>
        <li><Link href="/help">Help</Link></li>
      </ul>
    </div>
  );
}
