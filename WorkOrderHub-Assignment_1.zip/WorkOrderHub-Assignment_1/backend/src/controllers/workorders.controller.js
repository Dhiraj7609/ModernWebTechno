const { v4: uuidv4 } = require("uuid");
const { parse } = require("csv-parse/sync");
const service = require("../services/workorders.service");
const { sendSuccess } = require("../utils/response.util");
const { AppError } = require("../utils/errors.util");
const { CSV_REQUIRED_COLUMNS, DEPARTMENTS, PRIORITIES } = require("../utils/constants");

function normalizeHeaderKey(k) {
  return String(k || "").trim();
}

function validateCsvRow(row) {
  const errors = [];
  const title = String(row.title || "").trim();
  const description = String(row.description || "").trim();
  const department = String(row.department || "").trim();
  const priority = String(row.priority || "").trim();
  const requesterName = String(row.requesterName || "").trim();
  const assignee = row.assignee !== undefined ? String(row.assignee || "").trim() : "";

  if (title.length < 5) errors.push({ field: "title", reason: "Min 5 chars" });
  if (description.length < 10) errors.push({ field: "description", reason: "Min 10 chars" });
  if (!DEPARTMENTS.includes(department)) errors.push({ field: "department", reason: `Must be one of ${DEPARTMENTS.join(",")}` });
  if (!PRIORITIES.includes(priority)) errors.push({ field: "priority", reason: `Must be one of ${PRIORITIES.join(",")}` });
  if (requesterName.length < 3) errors.push({ field: "requesterName", reason: "Min 3 chars" });

  return { errors, clean: { title, description, department, priority, requesterName, assignee: assignee || undefined } };
}

exports.list = (req, res, next) => {
  try {
    const data = service.list(req.query);
    return sendSuccess(res, req.requestId, data);
  } catch (e) {
    next(e);
  }
};

exports.getById = (req, res, next) => {
  try {
    const data = service.getById(req.params.id);
    return sendSuccess(res, req.requestId, data);
  } catch (e) {
    next(e);
  }
};

exports.create = (req, res, next) => {
  try {
    const created = service.create(req.body);
    return sendSuccess(res, req.requestId, created, 201);
  } catch (e) {
    next(e);
  }
};

exports.update = (req, res, next) => {
  try {
    const updated = service.update(req.params.id, req.body);
    return sendSuccess(res, req.requestId, updated);
  } catch (e) {
    next(e);
  }
};

exports.changeStatus = (req, res, next) => {
  try {
    const updated = service.changeStatus(req.params.id, req.body.status);
    return sendSuccess(res, req.requestId, updated);
  } catch (e) {
    next(e);
  }
};

exports.remove = (req, res, next) => {
  try {
    service.remove(req.params.id);
    return res.status(204).send();
  } catch (e) {
    next(e);
  }
};

// CSV Bulk Upload (PARTIAL ACCEPTANCE strategy)
exports.bulkUpload = (req, res, next) => {
  try {
    if (!req.file) {
      throw new AppError({ statusCode: 400, code: "VALIDATION_ERROR", message: "CSV file is required (field name: file)", details: [] });
    }

    const text = req.file.buffer.toString("utf8");
    const records = parse(text, {
      columns: (header) => header.map(normalizeHeaderKey),
      skip_empty_lines: true,
      trim: true
    });

    // Validate headers
    const headers = Object.keys(records[0] || {});
    const missing = CSV_REQUIRED_COLUMNS.filter((c) => !headers.includes(c));
    if (missing.length > 0) {
      throw new AppError({
        statusCode: 400,
        code: "VALIDATION_ERROR",
        message: "CSV missing required headers",
        details: missing.map((m) => ({ field: m, reason: "Missing header" }))
      });
    }

    const uploadId = uuidv4();
    const strategy = "PARTIAL_ACCEPTANCE";

    let accepted = 0;
    let rejected = 0;
    const errors = [];
    const createdIds = [];

    // Row numbers: +2 because header is row 1 in spreadsheet terms
    records.forEach((row, idx) => {
      const rowNum = idx + 2;
      const { errors: rowErrors, clean } = validateCsvRow(row);

      if (rowErrors.length > 0) {
        rejected++;
        rowErrors.forEach((e) => errors.push({ row: rowNum, field: e.field, reason: e.reason }));
        return;
      }

      const created = service.create(clean);
      accepted++;
      createdIds.push(created.id);
    });

    return sendSuccess(res, req.requestId, {
      uploadId,
      strategy,
      totalRows: records.length,
      accepted,
      rejected,
      errors,
      createdIds
    });
  } catch (e) {
    next(e);
  }
};
