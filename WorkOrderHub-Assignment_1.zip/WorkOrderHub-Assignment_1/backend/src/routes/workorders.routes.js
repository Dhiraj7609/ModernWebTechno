const router = require("express").Router();
const multer = require("multer");
const auth = require("../middleware/auth.middleware");
const validate = require("../middleware/validate.middleware");
const ctrl = require("../controllers/workorders.controller");
const { AppError } = require("../utils/errors.util");

router.use(auth);

router.get("/", ctrl.list);
router.get("/:id", ctrl.getById);

router.post("/", validate("createWorkOrder"), ctrl.create);
router.put("/:id", validate("updateWorkOrder"), ctrl.update);
router.patch("/:id/status", validate("changeStatus"), ctrl.changeStatus);

router.delete("/:id", ctrl.remove);

// CSV upload config
const maxMb = parseInt(process.env.CSV_MAX_MB || "2", 10);
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: maxMb * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const ok = (file.mimetype === "text/csv") || String(file.originalname || "").toLowerCase().endsWith(".csv");
    if (!ok) {
      return cb(new AppError({
        statusCode: 415,
        code: "UNSUPPORTED_MEDIA_TYPE",
        message: "Only .csv files are allowed",
        details: [{ mimetype: file.mimetype, name: file.originalname }]
      }));
    }
    cb(null, true);
  }
});

// Primary endpoint (spec)
router.post("/bulk-upload", upload.single("file"), ctrl.bulkUpload);

// Alias endpoint in case your instructor uses a different name in the handout
router.post("/data-transfer", upload.single("file"), ctrl.bulkUpload);

module.exports = router;
