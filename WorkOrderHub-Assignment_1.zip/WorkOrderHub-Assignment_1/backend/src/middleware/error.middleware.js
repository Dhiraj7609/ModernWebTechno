const { sendError } = require("../utils/response.util");
const { AppError } = require("../utils/errors.util");

module.exports = function errorHandler(err, req, res, _next) {
  const requestId = req.requestId || "unknown";

  // Map Multer file-size error to 413
  if (err && err.name === "MulterError" && err.code === "LIMIT_FILE_SIZE") {
    return sendError(res, requestId, "PAYLOAD_TOO_LARGE", "CSV file too large", [], 413);
  }

  if (err instanceof AppError) {
    return sendError(res, requestId, err.code, err.message, err.details || [], err.statusCode);
  }

  console.error("UNHANDLED_ERROR", err);
  return sendError(res, requestId, "INTERNAL_ERROR", "Unexpected server error", [], 500);
};
