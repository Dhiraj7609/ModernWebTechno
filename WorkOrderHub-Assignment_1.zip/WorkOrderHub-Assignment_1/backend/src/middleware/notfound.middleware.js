const { AppError } = require("../utils/errors.util");

module.exports = function notFound(req, _res, next) {
  next(
    new AppError({
      statusCode: 404,
      code: "NOT_FOUND",
      message: `Route not found: ${req.method} ${req.originalUrl}`,
      details: []
    })
  );
};
