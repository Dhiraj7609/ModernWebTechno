const { AppError } = require("../utils/errors.util");
const { DEPARTMENTS, PRIORITIES, STATUSES } = require("../utils/constants");

function isString(v) {
  return typeof v === "string" && v.trim().length > 0;
}

function validateCreate(body) {
  const errors = [];
  if (!isString(body.title) || body.title.trim().length < 5) errors.push({ field: "title", reason: "Min 5 chars" });
  if (!isString(body.description) || body.description.trim().length < 10) errors.push({ field: "description", reason: "Min 10 chars" });
  if (!DEPARTMENTS.includes(body.department)) errors.push({ field: "department", reason: `Must be one of ${DEPARTMENTS.join(",")}` });
  if (!PRIORITIES.includes(body.priority)) errors.push({ field: "priority", reason: `Must be one of ${PRIORITIES.join(",")}` });
  if (!isString(body.requesterName) || body.requesterName.trim().length < 3) errors.push({ field: "requesterName", reason: "Min 3 chars" });
  return errors;
}

function validateUpdate(body) {
  const errors = [];
  const allowed = ["title", "description", "priority", "assignee"];
  for (const k of Object.keys(body || {})) {
    if (!allowed.includes(k)) errors.push({ field: k, reason: "Field not allowed in PUT" });
  }
  if (body.title && body.title.trim().length < 5) errors.push({ field: "title", reason: "Min 5 chars" });
  if (body.description && body.description.trim().length < 10) errors.push({ field: "description", reason: "Min 10 chars" });
  if (body.priority && !PRIORITIES.includes(body.priority)) errors.push({ field: "priority", reason: `Must be one of ${PRIORITIES.join(",")}` });
  return errors;
}

function validateStatus(body) {
  const errors = [];
  if (!STATUSES.includes(body.status)) errors.push({ field: "status", reason: `Must be one of ${STATUSES.join(",")}` });
  return errors;
}

module.exports = function validate(schemaName) {
  return (req, _res, next) => {
    let errors = [];
    if (schemaName === "createWorkOrder") errors = validateCreate(req.body);
    if (schemaName === "updateWorkOrder") errors = validateUpdate(req.body);
    if (schemaName === "changeStatus") errors = validateStatus(req.body);

    if (errors.length > 0) {
      return next(
        new AppError({
          statusCode: 400,
          code: "VALIDATION_ERROR",
          message: "Request validation failed",
          details: errors
        })
      );
    }

    next();
  };
};
