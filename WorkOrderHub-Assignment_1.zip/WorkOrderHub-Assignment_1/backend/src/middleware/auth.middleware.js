const { AppError } = require("../utils/errors.util");

module.exports = function auth(req, _res, next) {
  const key = req.header("x-api-key");
  const expected = process.env.API_KEY;

  if (!key || key !== expected) {
    return next(
      new AppError({
        statusCode: 401,
        code: "UNAUTHORIZED",
        message: "Missing or invalid API key",
        details: []
      })
    );
  }

  next();
};
