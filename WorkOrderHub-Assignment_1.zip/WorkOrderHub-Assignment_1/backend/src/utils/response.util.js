function sendSuccess(res, requestId, data, status = 200) {
  return res.status(status).json({
    requestId,
    success: true,
    data
  });
}

function sendError(res, requestId, code, message, details = [], status = 500) {
  return res.status(status).json({
    requestId,
    success: false,
    error: { code, message, details }
  });
}

module.exports = { sendSuccess, sendError };
