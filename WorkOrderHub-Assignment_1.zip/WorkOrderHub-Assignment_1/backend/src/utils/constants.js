const DEPARTMENTS = ["FACILITIES", "IT", "SECURITY", "HR"];
const PRIORITIES = ["LOW", "MEDIUM", "HIGH"];
const STATUSES = ["NEW", "IN_PROGRESS", "BLOCKED", "DONE"];

const ALLOWED_TRANSITIONS = {
  NEW: ["IN_PROGRESS"],
  IN_PROGRESS: ["BLOCKED", "DONE"],
  BLOCKED: ["IN_PROGRESS"],
  DONE: []
};

const CSV_REQUIRED_COLUMNS = ["title", "description", "department", "priority", "requesterName"];

module.exports = {
  DEPARTMENTS,
  PRIORITIES,
  STATUSES,
  ALLOWED_TRANSITIONS,
  CSV_REQUIRED_COLUMNS
};
