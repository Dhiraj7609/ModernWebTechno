const { v4: uuidv4 } = require("uuid");
const { workorders } = require("../data/workorders.store");
const { ALLOWED_TRANSITIONS } = require("../utils/constants");
const { AppError } = require("../utils/errors.util");

function nowIso() {
  return new Date().toISOString();
}

function list(query) {
  const items = Array.from(workorders.values());
  let filtered = items;

  if (query.status) filtered = filtered.filter(w => w.status === query.status);
  if (query.department) filtered = filtered.filter(w => w.department === query.department);
  if (query.priority) filtered = filtered.filter(w => w.priority === query.priority);
  if (query.assignee) filtered = filtered.filter(w => (w.assignee || "") === query.assignee);
  if (query.q) filtered = filtered.filter(w => w.title.toLowerCase().includes(String(query.q).toLowerCase()));

  const page = Math.max(1, parseInt(query.page || "1", 10));
  const limit = Math.max(1, parseInt(query.limit || "10", 10));
  const total = filtered.length;
  const start = (page - 1) * limit;
  const paged = filtered.slice(start, start + limit);

  return { items: paged, page, limit, total };
}

function getById(id) {
  const w = workorders.get(id);
  if (!w) {
    throw new AppError({ statusCode: 404, code: "NOT_FOUND", message: "Work order not found", details: [{ id }] });
  }
  return w;
}

function create(payload) {
  const id = uuidv4();
  const ts = nowIso();
  const w = {
    id,
    title: payload.title.trim(),
    description: payload.description.trim(),
    department: payload.department,
    priority: payload.priority,
    status: "NEW",
    requesterName: payload.requesterName.trim(),
    assignee: payload.assignee ? String(payload.assignee).trim() : null,
    createdAt: ts,
    updatedAt: ts
  };
  workorders.set(id, w);
  return w;
}

function update(id, payload) {
  const existing = getById(id);
  const next = { ...existing };

  if (payload.title) next.title = payload.title.trim();
  if (payload.description) next.description = payload.description.trim();
  if (payload.priority) next.priority = payload.priority;
  if (payload.assignee !== undefined) next.assignee = payload.assignee ? String(payload.assignee).trim() : null;

  next.updatedAt = nowIso();
  workorders.set(id, next);
  return next;
}

function changeStatus(id, newStatus) {
  const existing = getById(id);
  const allowed = ALLOWED_TRANSITIONS[existing.status] || [];

  if (!allowed.includes(newStatus)) {
    throw new AppError({
      statusCode: 409,
      code: "INVALID_TRANSITION",
      message: `Invalid transition: ${existing.status} -> ${newStatus}`,
      details: [{ from: existing.status, to: newStatus }]
    });
  }

  const next = { ...existing, status: newStatus, updatedAt: nowIso() };
  workorders.set(id, next);
  return next;
}

function remove(id) {
  getById(id);
  workorders.delete(id);
}

module.exports = { list, getById, create, update, changeStatus, remove };
