const express = require("express");
const requestIdMiddleware = require("./middleware/requestId.middleware");
const indexRoutes = require("./routes/index.routes");
const notFound = require("./middleware/notfound.middleware");
const errorHandler = require("./middleware/error.middleware");

const app = express();

// 1) express.json()
app.use(express.json());

// 2) requestId middleware
app.use(requestIdMiddleware);

// 3) (optional logging) - student level
app.use((req, _res, next) => {
  console.log(`${req.method} ${req.url} [requestId=${req.requestId}]`);
  next();
});

// 4) routes
app.use("/", indexRoutes);

// 5) notfound
app.use(notFound);

// 6) centralized error middleware
app.use(errorHandler);

module.exports = app;
