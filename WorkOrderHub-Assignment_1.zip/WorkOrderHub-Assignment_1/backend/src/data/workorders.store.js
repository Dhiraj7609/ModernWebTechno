const workorders = new Map();
module.exports = { workorders };
